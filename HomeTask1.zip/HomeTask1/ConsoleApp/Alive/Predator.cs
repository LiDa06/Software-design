namespace ConsoleApp.Alive
{
    public abstract class Predator(string name, int food) : Animal(name, food)
    {
    }
}