namespace ConsoleApp.Alive
{
    public class Tiger(string name, int food) : Predator(name, food)
    {
    }
}