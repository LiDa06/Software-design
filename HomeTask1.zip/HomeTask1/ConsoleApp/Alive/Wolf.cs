namespace ConsoleApp.Alive
{
    public class Wolf(string name, int food) : Predator(name, food)
    {
    }
}