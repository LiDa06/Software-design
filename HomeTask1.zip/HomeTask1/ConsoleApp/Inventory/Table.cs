namespace ConsoleApp.Inventory
{
    public class Table(int number) : Thing(number)
    {
    }
}