namespace ConsoleApp.Inventory
{
    public class Computer(int number) : Thing(number)
    {
    }
}