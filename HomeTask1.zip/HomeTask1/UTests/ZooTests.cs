﻿namespace UTests
{
    public class ZooTests
    {
        public static void Main()
        {
            Console.WriteLine("wtf");
        }
    }
}
